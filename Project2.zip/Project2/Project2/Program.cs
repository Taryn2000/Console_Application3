﻿using System;

namespace Project2
{
    class Program
    {
        static double total = 0;
        static string sline = "";
        static void Main(string[] args)
        {
            int level;
           

            do
            {
                Console.WriteLine("MENU");
                Console.WriteLine("1 Breakfast");
                Console.WriteLine("2 Combos");
                Console.WriteLine("3 Chips");
                Console.WriteLine("4 Burgers");
                Console.WriteLine("5 Drinks");
                Console.WriteLine("6 Checkout");
                Console.WriteLine("Please make your choice");
                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {
                    case mainMenu.Breakfast:
                        breakfast();
                        break;
                    case mainMenu.Combs:
                        combosmenue();
                        break;
                    case mainMenu.Chips:
                        chipsmenu();
                        break;
                    case mainMenu.Burgers:
                        burgers();
                        break;
                    case mainMenu.Drinks:
                        drinks();
                        break;
                    case mainMenu.Checkout:
                        Console.Clear();
                        checkout();
                        sline = "";
                        total = 0;
                        break;
                }

            } while (level != 7);



        }
        static void breakfast()
        {
            int level;
            int breakfastS = 0;
            int hasbrownEgg = 0;
            int SundayS = 0;

            do
            {
                Console.WriteLine("Breakfast");
                Console.WriteLine("1 Breakfast Special");
                Console.WriteLine("2 Hasbrown and egg");
                Console.WriteLine("3 Sunday Special");
                Console.WriteLine("4 Back");
                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {

                    case (mainMenu)breakfastmenu.BreakfastSpecial:
                        Console.Write("How many Breakfast special's would you like to order R40: ");
                        breakfastS += Int32.Parse(Console.ReadLine());
                       
                        break;

                    case (mainMenu)breakfastmenu.HashbrownAndEgg:
                        Console.Write("How many Hashbrown & Egg's would you like to order R20: ");
                        hasbrownEgg += Int32.Parse(Console.ReadLine());
                   
                        break;
                    case (mainMenu)breakfastmenu.SundaySpecial:
                        Console.Write("How many Sunday special's would you like to order R60: ");
                        SundayS += Int32.Parse(Console.ReadLine());
                        
                        break;

                }
               
            } while (level != 4);
            calculateBreakfastPrice(breakfastS, hasbrownEgg, SundayS);
        }

      

        static void calculateBreakfastPrice(int breakfastS,int hasbrownEgg,int SundayS)
        {
            
            double breakfastspecialP = breakfastS * 40;
            double hashbrownEggP = hasbrownEgg * 20;
            double SundaySP = SundayS * 60;
            total += breakfastspecialP + hashbrownEggP + SundaySP;
            if (breakfastspecialP>0)
            {
                sline += "\nBreakfast Special:"+breakfastS;
            }
            if (hashbrownEggP > 0)
            {
                sline += "\nHashbrown & Egg:"+hasbrownEgg;
            }
            if (SundaySP > 0)
            {
                sline += "\nSunday Special:"+SundayS;
            }


        }

        static void chipsmenu ()
        {
            int level;
            int chipsS = 0; 
            int chipsM = 0;
            int chipsL = 0;

            do
            {
                Console.WriteLine("Chips Sizes");
                Console.WriteLine("1 Small");
                Console.WriteLine("2 Meduim");
                Console.WriteLine("3 Large");
                Console.WriteLine("4 Back");
                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {

                    case (mainMenu)chipssizes.Small:
                      
                        Console.Write("How many chips would you like to have R20:");
                        chipsS += Int32.Parse(Console.ReadLine());
                

                break;

                    case (mainMenu)chipssizes.Meduim:
                        Console.Write("How many chips would you like to have R25:"); ;
                        chipsM += Int32.Parse(Console.ReadLine());

                        break;
                    case (mainMenu)chipssizes.Large:
                        Console.Write("How many chips would you like to have R30:");
                        chipsL += Int32.Parse(Console.ReadLine());

                        break;

                }

            } while (level != 4);
            calculateChipstPrice(chipsS, chipsM, chipsL);
        }

   static void calculateChipstPrice(int chipsS,int chipsM,int chipsL)
        {
            double chipssmallprice = chipsS * 20;
            double chipsmeduimprice = chipsM * 25;
            double chipslargeprice = chipsL * 30;
            total += chipssmallprice + chipsmeduimprice + chipslargeprice;
            if (chipssmallprice > 0)
            {
                sline += "\nSmall Chips:" + chipsS;
            }
            if (chipsmeduimprice > 0)
            {
                sline += "\nMeduim Chips:" + chipsM;
            }
            if (chipslargeprice > 0)
            {
                sline += "\nLarge Chips:" + chipsL;
            }

        }

        static void drinks()
        {
            int level;
            int softdrinks = 0;
            int milkshake = 0;
            int juice = 0;
           

            do
            {
                Console.WriteLine("Drinks");
                Console.WriteLine("1 Soft Drinks");
                Console.WriteLine("2 Milkshake");
                Console.WriteLine("3 Juice");
                Console.WriteLine("4 Hot Drinks");
                Console.WriteLine("5 Back");

                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {

                    case (mainMenu)drinksMenu.SoftDrinks:
                        Console.Write("How many Soft drink's would you like to order R15: ");
                        softdrinks += Int32.Parse(Console.ReadLine());
                        

                        break;

                    case (mainMenu)drinksMenu.Mikshake:
                        Console.Write("How many Milkshake's would you like to order R34: ");
                        milkshake += Int32.Parse(Console.ReadLine());
                        

                        break;
                    case (mainMenu)drinksMenu.Juice:
                        Console.Write("How many Juice's would you like to order R20: ");
                        juice += Int32.Parse(Console.ReadLine());
                   

                        break;

                    case (mainMenu)drinksMenu.HotDrinks:
                        hotdrinks();

                        break;

                }
               
            } while (level != 5);
            coldrinksPrice(softdrinks, milkshake, juice);
        }

      
        static void coldrinksPrice(int softdrinks,int milkshake,int juice)
        {
            double softdrinkprice = softdrinks * 15;
            double milkshakeprice = milkshake * 34;
            double juiceprice = juice * 20;
            total += softdrinkprice + milkshakeprice + juiceprice;
            if (softdrinkprice > 0)
            {
                sline += "\nSoft drink:"+softdrinks;
            }
            if (milkshakeprice > 0)
            {
                sline += "\nMilkshake:"+milkshake;
            }
            if (juiceprice > 0)
            {
                sline += "\nJuice:"+juice;
            }

        }


        static void hotdrinks()
        {
            int level;
            int cappachino = 0;
            int HotChocolate = 0;
            int coffee = 0;
            int tea = 0;

            do
            {
                Console.WriteLine("Hot Drinks");
                Console.WriteLine("1 Cappachino");
                Console.WriteLine("2 Hot chocolate");
                Console.WriteLine("3 Coffee");
                Console.WriteLine("4 Tea");
                Console.WriteLine("5 Back");

                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {

                    case (mainMenu)HotDrinksMenu.Cappachino:
                        Console.Write("How many Cappichino's would you like to order R30: ");
                        cappachino += Int32.Parse(Console.ReadLine());
                        

                        break;

                    case (mainMenu)HotDrinksMenu.HotChocolate:
                        Console.Write("How many Hot Chocolate's would you like to order R25: ");
                        HotChocolate += Int32.Parse(Console.ReadLine());
                        

                        break;
                    case (mainMenu)HotDrinksMenu.Coffee:
                        Console.Write("How many Coffee's would you like to order R20: ");
                        coffee += Int32.Parse(Console.ReadLine());
                   

                        break;

                    case (mainMenu)HotDrinksMenu.Tea:
                        Console.Write("How many Tea's would you like to order R20: ");
                        tea += Int32.Parse(Console.ReadLine());
                        


                        break;
                       
                }
               

            } while (level != 5);
            hotdrinkspricecalculations(cappachino, HotChocolate, coffee, tea);
        }

       

        static void hotdrinkspricecalculations(int cappachino,int HotChocolate,int coffee,int tea)
        {
            double cappichinoprice = cappachino * 30;
            double hotchocolateprice = HotChocolate * 25;
            double coffeeprice = coffee * 20;
            double teaprice = tea * 20;
            total += cappichinoprice + hotchocolateprice + coffeeprice+teaprice;
            if (cappichinoprice > 0)
            {
                sline += "\nCapichino:"+cappachino;
            }
            if (hotchocolateprice > 0)
            {
                sline += "\nHot Chocolate:"+HotChocolate;
            }
            if (coffeeprice > 0)
            {
                sline += "\nCoffee:"+coffee;
            }
            if (teaprice > 0)
            {
                sline += "\nTea:" + tea;
            }
        }

        

        static void burgers()
        {
            int level;
            int chickenB = 0;
            int beefb = 0;
            int veggib = 0;

            do
            {
                Console.WriteLine("Burgers");
                Console.WriteLine("1 Chicken Burger");
                Console.WriteLine("2 Beef Burger");
                Console.WriteLine("3 Veggie Burger");
                Console.WriteLine("4 Back");

                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {

                    case (mainMenu)BurgersMenu.ChickenBurger:
                        Console.Write("How many Chicken burger's would you like to order R20: ");
                        chickenB += Int32.Parse(Console.ReadLine());
                      
                        break;

                    case (mainMenu)BurgersMenu.BeefBurger:
                        Console.Write("How many Chicken burger's would you like to order R20: ");
                        beefb += Int32.Parse(Console.ReadLine());
                        
                        break;
                    case (mainMenu)BurgersMenu.VegieBurger:
                        Console.Write("How many Veggie Burger's would you like to order R20: ");
                        veggib += Int32.Parse(Console.ReadLine());
                       
                        break;

                }
                
            } while (level != 4);
            burgerpricecalc(chickenB, beefb, veggib);
        }

       

        static void burgerpricecalc(int chickenb, int beefb, int veggib)
        {


            double chickenprice = chickenb * 25;
            double beefprice = beefb * 30;
            double veggieprice = veggib * 20;

            total += chickenprice + beefprice + veggieprice;
            if (chickenprice > 0)
            {
                sline += "\nChicken Burger:" + chickenb;
            }
            if (beefprice > 0)
            {
                sline += "\nBeef Burger:" + beefb;
            }
            if (veggieprice > 0)
            {
                sline += "\nVeggie Burger:" + veggib;
            }
        }
        static void combosmenue()
        {
            int level;
            int comb = 0;

            do
            {
                Console.WriteLine("Combo");
                Console.WriteLine("1 Burger & Chips");
            
                Console.WriteLine("2 Back");

                level = Int32.Parse(Console.ReadLine());

                switch ((mainMenu)level)
                {

                    case (mainMenu)combos.BurgerChips:
                        Console.Write("How many Combo's would you like to order R40: ");
                        comb += Int32.Parse(Console.ReadLine());
                        

                        break;

                }

            } while (level != 2);
            combopricecalc(comb);
        }

        static void combopricecalc (int comb)
        {
            double comboprive = comb * 40;
            if (comboprive > 0)
                total += comboprive;
            {
                sline += "\nCombo:" + comb;
            }
        }

        enum mainMenu
        {
            Breakfast = 1,
            Combs,
            Chips,
            Burgers,
            Drinks,
            Checkout


        }
        enum breakfastmenu
        {
            BreakfastSpecial = 1,
            HashbrownAndEgg,
            SundaySpecial,
            Back
        }

        enum chipssizes
        {
            Small=1,
            Meduim,
            Large
        }

        enum drinksMenu
        {
            SoftDrinks = 1,
            Mikshake,
            Juice,
            HotDrinks,
            Back
        }
        enum HotDrinksMenu
        {
            Cappachino=1,
            HotChocolate,
            Coffee,
            Tea,
            Back
        }

        enum BurgersMenu
        {
            ChickenBurger=1,
            BeefBurger,
            VegieBurger
        }

        enum combos
        {
            BurgerChips=1,
          
        }

        static void checkout()
        {
            Console.WriteLine("Your Order:");
            Console.WriteLine(sline);
            Console.WriteLine("Your total amounts to:R" + total+"\n");
        }

    }
}
  
